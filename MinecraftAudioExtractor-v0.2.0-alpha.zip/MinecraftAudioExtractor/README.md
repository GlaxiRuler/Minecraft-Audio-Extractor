# Minecraft Audio Extractor — Alpha 2

Browse the sounds already stored in a local Minecraft asset cache, preview
them, and export selected OGG files. The app only reads Minecraft's cache; it
does not change game files or download assets.

## Start

- From **Workspace Tools**, select a project and run **Minecraft Audio
  Extractor**.
- Or open PowerShell in this folder and run `python main.py`.

The desktop window opens maximized so the sound list and controls have room.

The usual Minecraft folder on Windows is `%APPDATA%\.minecraft`. The app
remembers the last folder you chose. When started from a project, the default
export folder is `E:\.Output\<Project>\MinecraftAudioExtractor`.

## Screen and controls

| Control | What it does |
| --- | --- |
| **Minecraft folder** | Points to `.minecraft` (the folder containing `assets`). Choose the folder itself, not its `assets` subfolder. |
| **Browse…** beside Minecraft folder | Pick a `.minecraft` folder. The app saves this choice for next time and refreshes the available indexes. |
| **Asset index** | Chooses which local Minecraft version's sound list to read. The newest modified index is selected by default. |
| **Refresh indexes** | Re-reads `assets\indexes` after you change or update Minecraft versions. |
| **Scan sounds** | Reads the chosen index and lists its OGG sounds. Scanning runs in the background; watch the status line. |
| **Search** | Filters the loaded list as you type. Search is case-insensitive and matches part of a sound path or name. |
| **Category** | Shows all sounds or only one category, such as `music`, `ambient`, or `entity`. Categories come from the first folder in the sound path. |
| **Select box beside a sound** | Checks or unchecks that sound for preview/export. Checked items remain checked while you change search or category filters. |
| **Select all shown** | Checks every row currently visible after search/category filtering. Click again to uncheck those visible rows. |
| **Sound table** | Shows sound name, category, cached file size, and whether its audio data is available. |
| **Preview checked** | Plays the first checked sound. Double-click any sound row to preview it directly. |
| **Stop** | Stops the current preview. |
| **Export checked** | Copies every checked, available OGG into the export folder while keeping its `sounds` subfolders. |
| **Export folder** | Shows where exports will go. Type a path or use **Browse…** to choose a different folder for this run. |
| **Open** | Opens the export folder in File Explorer, creating it if needed. |
| **Status / progress** | Reports scan and export results. Missing cache files are reported and skipped. |

## Typical workflow

1. Start the app and check the Minecraft folder. Choose the `.minecraft`
   directory if the path is wrong.
2. Choose the version in **Asset index**, then click **Scan sounds**.
3. Type a word in **Search**, choose a **Category**, or leave both broad to
   browse everything in that index.
4. Click the box beside each sound you want. Use **Select all shown** to check
   the current filtered list at once. Click a checked box again to uncheck it.
   Double-click a row to preview it immediately.
5. Check **Export folder**. Keep the project default or browse to another
   destination, then click **Export checked**.
6. Click **Open** to see the copied files.

Exports are copies of the original OGG data, arranged like
`<export folder>\sounds\<sound path>`. If a filename already exists, the app
adds a number such as `(2)` instead of replacing the earlier file. It never
exports or modifies the Minecraft cache itself.

## Missing sounds and preview setup

An index can list a sound whose cached audio file is absent. Such a row shows
**Missing** and cannot be previewed or exported. Refreshing indexes will not
restore missing cache data; launch or repair that Minecraft version so its
assets are available.

Browsing and exporting need only Python 3.10+ with Tkinter. Preview also needs
`ffplay.exe` from FFmpeg, normally at
`E:\.TerminalTools\ffmpeg\bin\ffplay.exe`. If preview reports that FFplay is
missing, install or locate FFmpeg; the rest of the app can still be used.

The app reads modern hashed files under `assets\objects` and legacy virtual
assets under `assets\virtual\legacy` when the selected index uses that layout.
It scans the selected asset index, not arbitrary resource-pack folders.
Minecraft sound assets are OGG files; exported sounds are not converted.

## Settings and requirements

The selected Minecraft folder is remembered in
`%LOCALAPPDATA%\MinecraftAudioExtractor\settings.json`. If that file is not
present, the app checks its earlier settings location for compatibility; the
next save uses the current location.

The app uses only Python's standard library. FFmpeg/FFplay is optional and is
used only for audio preview.

