"""Start Minecraft Audio Extractor Alpha 2."""

import os
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    bundle = Path(sys._MEIPASS)
    os.environ.setdefault("TCL_LIBRARY", str(bundle / "tcl8.6"))
    os.environ.setdefault("TK_LIBRARY", str(bundle / "tk8.6"))

import tkinter as tk

from app.ui.main_window import MainWindow


def main():
    root = tk.Tk()
    MainWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
