"""Tkinter's DLLs and Tcl/Tk data are supplied explicitly by the build."""
