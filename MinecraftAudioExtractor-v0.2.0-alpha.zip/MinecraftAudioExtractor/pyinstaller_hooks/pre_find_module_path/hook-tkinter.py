"""Keep tkinter discoverable; the build bundles Tcl/Tk files explicitly."""


def pre_find_module_path(hook_api):
    # PyInstaller's default probe rejects this host's Tcl registration and
    # removes tkinter from module discovery. The Alpha 2 build supplies the
    # Tcl/Tk data and DLLs explicitly, so leave normal module search enabled.
    return None
