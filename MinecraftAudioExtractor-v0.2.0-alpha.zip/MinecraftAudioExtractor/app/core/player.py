"""Minimal ffplay wrapper for previewing OGG files."""

import os
import subprocess
import sys
from pathlib import Path


def find_ffplay():
    candidates = []
    configured = os.environ.get("FFMPEG_PATH")
    if configured:
        candidates.append(Path(configured).expanduser().with_name("ffplay.exe"))

    configured_root = os.environ.get("TERMINAL_TOOLS_ROOT")
    if configured_root:
        terminal_tools = Path(configured_root).expanduser()
    elif getattr(sys, "frozen", False):
        terminal_tools = Path(sys.executable).resolve().parent.parent.parent / ".TerminalTools"
    else:
        terminal_tools = Path(__file__).resolve().parents[3].parent / ".TerminalTools"
    candidates.extend([
        terminal_tools / "ffmpeg" / "bin" / "ffplay.exe",
        terminal_tools / "ffmpeg" / "ffplay.exe",
    ])
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


class AudioPlayer:
    def __init__(self):
        self.process = None

    def play(self, path):
        self.stop()
        executable = find_ffplay()
        if not executable:
            raise FileNotFoundError("ffplay was not found. Install FFmpeg to preview sounds.")
        self.process = subprocess.Popen(
            [str(executable), "-nodisp", "-autoexit", "-loglevel", "error", str(path)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )

    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
        self.process = None
