"""Small, user-local settings file for Minecraft Audio Extractor."""

import json
import os
from pathlib import Path


def settings_path():
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
    return base / "MinecraftAudioExtractor" / "settings.json"


def legacy_settings_path():
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
    return base / "MinecraftAudioStudio" / "settings.json"


def load_settings():
    for path in (settings_path(), legacy_settings_path()):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            continue
        if isinstance(value, dict):
            return value
    return {}


def save_settings(values):
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(values, indent=2), encoding="utf-8")
    temporary.replace(path)
