"""Read sound entries from a local Minecraft asset index."""

import json
import shutil
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


@dataclass(frozen=True)
class SoundAsset:
    path: str
    category: str
    source: Path
    size: int
    available: bool

    @property
    def name(self):
        return self.path[:-4] if self.path.lower().endswith(".ogg") else self.path


def find_indexes(minecraft_dir):
    index_dir = Path(minecraft_dir).expanduser() / "assets" / "indexes"
    if not index_dir.is_dir():
        return []

    def modified(path):
        try:
            return path.stat().st_mtime
        except OSError:
            return 0

    return sorted(
        index_dir.glob("*.json"),
        key=modified,
        reverse=True,
    )


def scan_sound_index(minecraft_dir, index_name):
    root = Path(minecraft_dir).expanduser()
    index_path = root / "assets" / "indexes" / f"{index_name}.json"
    if not index_path.is_file():
        raise FileNotFoundError(f"Minecraft asset index not found: {index_path}")

    try:
        data = json.loads(index_path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Could not read asset index {index_path.name}: {exc}") from exc

    objects = data.get("objects") if isinstance(data, dict) else None
    if not isinstance(objects, dict):
        raise ValueError(f"{index_path.name} does not contain a Minecraft asset list.")

    is_virtual = bool(data.get("virtual"))
    object_root = root / "assets" / "objects"
    virtual_root = root / "assets" / "virtual" / "legacy"
    sounds = []
    for logical_path, metadata in objects.items():
        key = str(logical_path).replace("\\", "/")
        if key.startswith("minecraft/sounds/"):
            relative = key[len("minecraft/sounds/"):]
            virtual_relative = PurePosixPath("sounds") / PurePosixPath(relative)
        elif key.startswith("sounds/"):
            relative = key[len("sounds/"):]
            virtual_relative = PurePosixPath(key)
        elif key.startswith("sound/"):
            relative = key[len("sound/"):]
            virtual_relative = PurePosixPath(key)
        else:
            continue

        safe_relative = PurePosixPath(relative)
        if (
            not relative
            or safe_relative.is_absolute()
            or ".." in safe_relative.parts
            or safe_relative.suffix.lower() != ".ogg"
            or not isinstance(metadata, dict)
        ):
            continue

        digest = metadata.get("hash")
        if not isinstance(digest, str) or len(digest) < 2 or any(c not in "0123456789abcdefABCDEF" for c in digest):
            continue

        digest = digest.lower()
        source = object_root / digest[:2] / digest
        if is_virtual:
            legacy_source = virtual_root.joinpath(*virtual_relative.parts)
            if legacy_source.is_file():
                source = legacy_source
        try:
            size = int(metadata.get("size", source.stat().st_size if source.is_file() else 0))
        except (TypeError, ValueError, OSError):
            size = 0
        category = safe_relative.parts[0] if safe_relative.parts else "Other"
        sounds.append(SoundAsset(relative, category, source, size, source.is_file()))

    sounds.sort(key=lambda asset: asset.path.casefold())
    return sounds


def export_sounds(sounds, destination, progress=None):
    """Copy selected OGG assets, preserving their paths and existing exports."""
    root = Path(destination).expanduser()
    exported = 0
    errors = []

    for index, sound in enumerate(sounds, start=1):
        if progress and (index == 1 or index % 10 == 0 or index == len(sounds)):
            progress(index, len(sounds))
        if not sound.available:
            errors.append(f"Missing from asset cache: {sound.path}")
            continue

        target = root / "sounds" / Path(*PurePosixPath(sound.path).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        candidate = target
        number = 2
        while candidate.exists():
            candidate = target.with_name(f"{target.stem} ({number}){target.suffix}")
            number += 1
        try:
            shutil.copy2(sound.source, candidate)
            exported += 1
        except OSError as exc:
            errors.append(f"{sound.path}: {exc}")

    return exported, errors
