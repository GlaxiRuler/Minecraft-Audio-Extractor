"""A small, functional desktop interface for local Minecraft sound assets."""

import os
import queue
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from app.core.assets import export_sounds, find_indexes, scan_sound_index
from app.core.player import AudioPlayer
from app.core.settings import load_settings, save_settings


def default_minecraft_dir():
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / ".minecraft"


def default_output_dir():
    if getattr(sys, "frozen", False):
        workspace_root = Path(sys.executable).resolve().parent.parent.parent
    else:
        workspace_root = Path(__file__).resolve().parents[3].parent
    default_root = workspace_root / ".Output"
    output_root = Path(os.environ.get("AI_OUTPUT_ROOT", str(default_root))).expanduser()
    project = os.environ.get("AI_WORKSPACE_PROJECT")
    project_name = Path(project).name if project else "Standalone"
    return output_root / project_name / "MinecraftAudioExtractor"


class MainWindow(ttk.Frame):
    def __init__(self, root):
        super().__init__(root, padding=18)
        self.root = root
        self.root.title("Minecraft Audio Extractor — Alpha 2")
        self.root.geometry("1280x850")
        self.root.minsize(940, 640)
        self.root.after_idle(lambda: self.root.state("zoomed"))
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        saved = load_settings()
        self.minecraft_var = tk.StringVar(value=saved.get("minecraft_dir", str(default_minecraft_dir())))
        self.output_var = tk.StringVar(value=str(default_output_dir()))
        self.index_var = tk.StringVar()
        self.search_var = tk.StringVar()
        self.category_var = tk.StringVar(value="All categories")
        self.status_var = tk.StringVar(value="Choose your Minecraft folder, then scan its sound index.")
        self.sounds = []
        self.visible_sounds = {}
        self.checked_sounds = set()
        self.events = queue.Queue()
        self.player = AudioPlayer()
        self.busy = False

        self._style()
        self._build()
        self.refresh_indexes()
        self.root.after(100, self._poll_events)

    def _style(self):
        style = ttk.Style(self.root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        self.root.configure(bg="#f3f5f7")
        style.configure("TFrame", background="#f3f5f7")
        style.configure("Card.TFrame", background="#ffffff", relief="solid", borderwidth=1)
        style.configure("TLabel", background="#f3f5f7", foreground="#24313b", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), foreground="#17232c")
        style.configure("Hint.TLabel", foreground="#63717b")
        style.configure("Card.TLabel", background="#ffffff", foreground="#24313b", font=("Segoe UI", 10))
        style.configure("TButton", font=("Segoe UI", 10), padding=(10, 7))
        style.configure("Accent.TButton", background="#176b65", foreground="#ffffff", font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#0f5752"), ("disabled", "#aab9b7")])
        style.configure("Treeview", rowheight=27, font=("Segoe UI", 10), background="#ffffff", fieldbackground="#ffffff")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), padding=7)

    def _build(self):
        self.pack(fill="both", expand=True)
        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0, 15))
        ttk.Label(header, text="Minecraft Audio Extractor", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Browse local sound assets, preview them, and copy selected OGG files to your project output.",
            style="Hint.TLabel",
        ).pack(anchor="w", pady=(3, 0))

        source = ttk.Frame(self, style="Card.TFrame", padding=12)
        source.pack(fill="x", pady=(0, 10))
        ttk.Label(source, text="Minecraft folder", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        self.minecraft_entry = ttk.Entry(source, textvariable=self.minecraft_var)
        self.minecraft_entry.grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Button(source, text="Browse…", command=self.choose_minecraft).grid(row=0, column=2, padx=(8, 0), pady=4)

        ttk.Label(source, text="Asset index", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        self.index_combo = ttk.Combobox(source, textvariable=self.index_var, state="readonly", width=26)
        self.index_combo.grid(row=1, column=1, sticky="w", pady=4)
        self.refresh_button = ttk.Button(source, text="Refresh indexes", command=self.refresh_indexes)
        self.refresh_button.grid(row=1, column=2, padx=(8, 0), pady=4, sticky="ew")
        source.columnconfigure(1, weight=1)

        output = ttk.Frame(self, style="Card.TFrame", padding=12)
        output.pack(fill="x", pady=(0, 10))
        ttk.Label(output, text="Export folder", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.output_entry = ttk.Entry(output, textvariable=self.output_var)
        self.output_entry.grid(row=0, column=1, sticky="ew")
        ttk.Button(output, text="Browse…", command=self.choose_output).grid(row=0, column=2, padx=(8, 0))
        ttk.Button(output, text="Open", command=self.open_output).grid(row=0, column=3, padx=(8, 0))
        output.columnconfigure(1, weight=1)

        actions = ttk.Frame(self)
        actions.pack(fill="x", pady=(0, 8))
        ttk.Label(actions, text="Search").pack(side="left", padx=(0, 6))
        search = ttk.Entry(actions, textvariable=self.search_var, width=30)
        search.pack(side="left", padx=(0, 12))
        search.bind("<KeyRelease>", lambda _event: self.refresh_table())
        ttk.Label(actions, text="Category").pack(side="left", padx=(0, 6))
        self.category_combo = ttk.Combobox(
            actions, textvariable=self.category_var, state="readonly", width=20,
            values=["All categories"],
        )
        self.category_combo.pack(side="left")
        self.category_combo.bind("<<ComboboxSelected>>", lambda _event: self.refresh_table())
        self.scan_button = ttk.Button(actions, text="Scan sounds", style="Accent.TButton", command=self.scan)
        self.scan_button.pack(side="right")

        selection_bar = ttk.Frame(self)
        selection_bar.pack(fill="x", pady=(0, 8))
        self.select_all_var = tk.BooleanVar(value=False)
        self.select_all_box = ttk.Checkbutton(
            selection_bar,
            text="Select all shown",
            variable=self.select_all_var,
            command=self._toggle_all_visible,
        )
        self.select_all_box.pack(side="left")
        ttk.Label(selection_bar, text="Click a box beside a sound to select it.", style="Hint.TLabel").pack(side="left", padx=(10, 0))
        self.preview_button = ttk.Button(selection_bar, text="Preview checked", command=self.preview, state="disabled")
        self.preview_button.pack(side="right")
        self.stop_button = ttk.Button(selection_bar, text="Stop", command=self.player.stop)
        self.stop_button.pack(side="right", padx=(0, 6))
        self.export_button = ttk.Button(selection_bar, text="Export checked", style="Accent.TButton", command=self.export_selected, state="disabled")
        self.export_button.pack(side="right", padx=(0, 6))

        table_frame = ttk.Frame(self, style="Card.TFrame", padding=8)
        table_frame.pack(fill="both", expand=True)
        columns = ("select", "sound", "category", "size", "status")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="none")
        self.table.heading("select", text="Select")
        self.table.heading("sound", text="Sound")
        self.table.heading("category", text="Category")
        self.table.heading("size", text="Size")
        self.table.heading("status", text="Status")
        self.table.column("select", width=68, minwidth=68, anchor="center", stretch=False)
        self.table.column("sound", width=550, anchor="w")
        self.table.column("category", width=130, anchor="w")
        self.table.column("size", width=90, anchor="e")
        self.table.column("status", width=100, anchor="center")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        self.table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.table.bind("<Button-1>", self._checkbox_click)
        self.table.bind("<Double-1>", self._preview_row)

        footer = ttk.Frame(self)
        footer.pack(fill="x", pady=(10, 0))
        self.progress = ttk.Progressbar(footer, mode="indeterminate", length=150)
        self.progress.pack(side="right", padx=(10, 0))
        ttk.Label(footer, textvariable=self.status_var, style="Hint.TLabel").pack(side="right")

    def choose_minecraft(self):
        current = Path(self.minecraft_var.get()).expanduser()
        initial = current if current.is_dir() else default_minecraft_dir().parent
        path = filedialog.askdirectory(title="Select the .minecraft folder", initialdir=str(initial))
        if path:
            self.minecraft_var.set(path)
            self._save_settings()
            self.refresh_indexes()

    def choose_output(self):
        path = filedialog.askdirectory(title="Choose an export folder", initialdir=self.output_var.get())
        if path:
            self.output_var.set(path)

    def refresh_indexes(self):
        try:
            indexes = find_indexes(self.minecraft_var.get())
        except OSError as exc:
            self.status_var.set(f"Could not read asset indexes: {exc}")
            self.index_combo.configure(values=[])
            self.index_var.set("")
            self.scan_button.configure(state="disabled")
            return
        names = [path.stem for path in indexes]
        self.index_combo.configure(values=names)
        if names:
            current = self.index_var.get()
            self.index_var.set(current if current in names else names[0])
            self.status_var.set(f"Found {len(names)} local asset index(es).")
            self.scan_button.configure(state="normal")
        else:
            self.index_var.set("")
            self.status_var.set("No asset indexes found. Check that this is your .minecraft folder.")
            self.scan_button.configure(state="disabled")

    def scan(self):
        minecraft_dir = self.minecraft_var.get().strip()
        index_name = self.index_var.get().strip()
        if not minecraft_dir or not index_name:
            messagebox.showinfo("Choose an asset index", "Select your .minecraft folder and an asset index first.", parent=self.root)
            return
        self._save_settings()
        self._set_busy(True, "Reading the selected asset index…")
        threading.Thread(target=self._scan_worker, args=(minecraft_dir, index_name), daemon=True).start()

    def _scan_worker(self, minecraft_dir, index_name):
        try:
            sounds = scan_sound_index(minecraft_dir, index_name)
            self.events.put(("scan_done", sounds))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def refresh_table(self):
        query = self.search_var.get().strip().casefold()
        category = self.category_var.get()
        self.table.delete(*self.table.get_children())
        self.visible_sounds.clear()
        for index, sound in enumerate(self.sounds):
            if category != "All categories" and sound.category != category:
                continue
            if query and query not in sound.path.casefold():
                continue
            iid = f"sound-{index}"
            self.visible_sounds[iid] = sound
            self.table.insert(
                "", "end", iid=iid,
                values=("☑" if sound in self.checked_sounds else "☐", sound.name, sound.category, self._format_size(sound.size), "Ready" if sound.available else "Missing"),
            )
        if self.sounds:
            self.status_var.set(f"Showing {len(self.visible_sounds)} of {len(self.sounds)} sounds.")
        else:
            self.status_var.set("No sounds loaded. Select an asset index and scan.")
        self._selection_changed()
        self._update_select_all()

    def _checkbox_click(self, event):
        if self.table.identify_region(event.x, event.y) != "cell":
            return
        if self.table.identify_column(event.x) != "#1":
            return
        iid = self.table.identify_row(event.y)
        sound = self.visible_sounds.get(iid)
        if sound is None:
            return
        if sound in self.checked_sounds:
            self.checked_sounds.remove(sound)
        else:
            self.checked_sounds.add(sound)
        self.table.set(iid, "select", "☑" if sound in self.checked_sounds else "☐")
        self._selection_changed()
        self._update_select_all()
        return "break"

    def _toggle_all_visible(self):
        visible = set(self.visible_sounds.values())
        if self.select_all_var.get():
            self.checked_sounds.update(visible)
        else:
            self.checked_sounds.difference_update(visible)
        self.refresh_table()

    def _update_select_all(self):
        if not hasattr(self, "select_all_box"):
            return
        total = len(self.visible_sounds)
        checked = sum(sound in self.checked_sounds for sound in self.visible_sounds.values())
        if total and checked == total:
            self.select_all_var.set(True)
            self.select_all_box.state(["!alternate"])
        elif checked:
            self.select_all_var.set(False)
            self.select_all_box.state(["alternate"])
        else:
            self.select_all_var.set(False)
            self.select_all_box.state(["!alternate"])
        self.select_all_box.configure(state="normal" if total and not self.busy else "disabled")

    def _selection_changed(self):
        state = "normal" if self.checked_sounds and not self.busy else "disabled"
        if hasattr(self, "preview_button"):
            self.preview_button.configure(state=state)
            self.export_button.configure(state=state)

    def preview(self):
        sound = next((item for item in self.sounds if item in self.checked_sounds), None)
        if sound is None:
            return
        self._preview_sound(sound)

    def _preview_row(self, event):
        iid = self.table.identify_row(event.y)
        sound = self.visible_sounds.get(iid)
        if sound is not None:
            self._preview_sound(sound)

    def _preview_sound(self, sound):
        if not sound.available:
            messagebox.showwarning("Sound is missing", "This sound is listed in the index but is not present in the local asset cache.", parent=self.root)
            return
        try:
            self.player.play(sound.source)
            self.status_var.set(f"Playing {sound.name}")
        except (OSError, FileNotFoundError) as exc:
            messagebox.showerror("Could not preview sound", str(exc), parent=self.root)

    def export_selected(self):
        selected = [sound for sound in self.sounds if sound in self.checked_sounds]
        if not selected:
            return
        destination = self.output_var.get().strip()
        if not destination:
            messagebox.showinfo("Choose an export folder", "Choose where the selected sounds should be copied.", parent=self.root)
            return
        self._set_busy(True, f"Exporting {len(selected)} sound(s)…")
        threading.Thread(target=self._export_worker, args=(selected, destination), daemon=True).start()

    def _export_worker(self, sounds, destination):
        def report(index, total):
            self.events.put(("progress", (index, total)))

        try:
            result = export_sounds(sounds, destination, report)
            self.events.put(("export_done", result))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def open_output(self):
        value = self.output_var.get().strip()
        if not value:
            messagebox.showinfo("Choose an export folder", "Enter or browse to an export folder first.", parent=self.root)
            return
        path = Path(value).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(path))
        except (AttributeError, OSError) as exc:
            messagebox.showerror("Could not open folder", str(exc), parent=self.root)

    def _set_busy(self, busy, message=None):
        self.busy = busy
        self.scan_button.configure(state="disabled" if busy else "normal")
        self.refresh_button.configure(state="disabled" if busy else "normal")
        self._selection_changed()
        self._update_select_all()
        self.progress.start(12) if busy else self.progress.stop()
        if message:
            self.status_var.set(message)

    def _poll_events(self):
        try:
            while True:
                name, payload = self.events.get_nowait()
                if name == "scan_done":
                    self.sounds = payload
                    self.checked_sounds.intersection_update(payload)
                    categories = ["All categories", *sorted({sound.category for sound in payload}, key=str.casefold)]
                    self.category_combo.configure(values=categories)
                    self.category_var.set("All categories")
                    self.refresh_table()
                    self._set_busy(False, f"Loaded {len(payload)} sound(s) from {self.index_var.get()}.")
                elif name == "progress":
                    index, total = payload
                    self.status_var.set(f"Copying {index} of {total}…")
                elif name == "export_done":
                    count, errors = payload
                    self._set_busy(False, f"Exported {count} sound(s) to {self.output_var.get()}.")
                    if errors:
                        messagebox.showwarning("Some sounds were skipped", "\n".join(errors[:8]), parent=self.root)
                elif name == "error":
                    self._set_busy(False, "The operation could not be completed.")
                    messagebox.showerror("Minecraft Audio Extractor", payload, parent=self.root)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_events)

    def _save_settings(self):
        try:
            save_settings({"minecraft_dir": self.minecraft_var.get().strip()})
        except OSError as exc:
            self.status_var.set(f"Could not save settings: {exc}")

    def close(self):
        self._save_settings()
        self.player.stop()
        self.root.destroy()

    @staticmethod
    def _format_size(size):
        if size >= 1024 * 1024:
            return f"{size / (1024 * 1024):.1f} MB"
        if size >= 1024:
            return f"{size / 1024:.1f} KB"
        return f"{size} B"
