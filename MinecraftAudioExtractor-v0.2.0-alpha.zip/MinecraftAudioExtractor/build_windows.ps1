$ErrorActionPreference = 'Stop'

$python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'
if (-not (Test-Path $python)) {
    $launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($launcher) {
        $candidate = (& $launcher.Source -3.11 -c 'import sys; print(sys.executable)' 2>$null | Select-Object -First 1)
        if ($candidate -and (Test-Path $candidate)) {
            $python = $candidate
        }
    }
}
if (-not (Test-Path $python)) {
    throw 'Python 3.11 was not found. Install Python 3.11 for Windows with Tcl/Tk.'
}

$version = & $python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'
if ($version -ne '3.11') {
    throw "Python 3.11 is required; found Python $version."
}
& $python -m PyInstaller --version *> $null
if ($LASTEXITCODE -ne 0) {
    throw 'PyInstaller is missing. Run: py -3.11 -m pip install -r requirements-build.txt'
}

$pythonRoot = Split-Path -Parent $python
$dllDirectory = Join-Path $pythonRoot 'DLLs'
$tclDirectory = Join-Path $pythonRoot 'tcl\tcl8.6'
$tkDirectory = Join-Path $pythonRoot 'tcl\tk8.6'
$requiredFiles = @(
    (Join-Path $dllDirectory '_tkinter.pyd'),
    (Join-Path $dllDirectory 'tcl86t.dll'),
    (Join-Path $dllDirectory 'tk86t.dll'),
    $tclDirectory,
    $tkDirectory
)
foreach ($requiredFile in $requiredFiles) {
    if (-not (Test-Path $requiredFile)) {
        throw "The Python Tcl/Tk runtime is incomplete: $requiredFile"
    }
}

$buildRoot = Join-Path ([System.IO.Path]::GetTempPath()) 'MinecraftAudioExtractor-Alpha2'
$workPath = Join-Path $buildRoot 'work'
New-Item -ItemType Directory -Force -Path $workPath | Out-Null

$pyInstallerArgs = @(
    '--noconfirm', '--clean', '--onefile', '--windowed',
    '--additional-hooks-dir', (Join-Path $PSScriptRoot 'pyinstaller_hooks'),
    '--hidden-import=tkinter', '--hidden-import=_tkinter',
    '--add-binary', "$(Join-Path $dllDirectory '_tkinter.pyd');.",
    '--add-binary', "$(Join-Path $dllDirectory 'tcl86t.dll');.",
    '--add-binary', "$(Join-Path $dllDirectory 'tk86t.dll');.",
    '--add-data', "$($tclDirectory);tcl8.6",
    '--add-data', "$($tkDirectory);tk8.6",
    '--name', 'Minecraft-Audio-Extractor-Alpha-2',
    '--distpath', $PSScriptRoot,
    '--workpath', $workPath,
    '--specpath', $buildRoot,
    (Join-Path $PSScriptRoot 'main.py')
)

Push-Location $PSScriptRoot
try {
    & $python -m PyInstaller @pyInstallerArgs
    if ($LASTEXITCODE -ne 0) {
        throw "PyInstaller failed with exit code $LASTEXITCODE."
    }
} finally {
    Pop-Location
}

Write-Host "Built: $(Join-Path $PSScriptRoot 'Minecraft-Audio-Extractor-Alpha-2.exe')"
